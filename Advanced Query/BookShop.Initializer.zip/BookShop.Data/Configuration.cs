﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => @"Server=DESKTOP-SF8TSQ3\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
