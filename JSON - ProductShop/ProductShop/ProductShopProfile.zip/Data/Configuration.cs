﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
           @"Server=DESKTOP-SF8TSQ3\SQLEXPRESS;Database=ProductShop;Integrated Security=True;";
    }
}
