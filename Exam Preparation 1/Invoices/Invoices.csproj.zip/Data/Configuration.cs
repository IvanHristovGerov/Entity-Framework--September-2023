﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-SF8TSQ3\SQLEXPRESS;Database=Invoices;Integrated Security=True;Encrypt=False";
    }
}
